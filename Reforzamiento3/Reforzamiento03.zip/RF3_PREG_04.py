# PREGUNTA N4
# ROGER VERA
# 25/07/2025


# Programa para formatear números decimales
print("Número decimal con 6 dígitos en la parte decimal")
numero = float(input("Ingrese un número: "))

print("\nRESULTADO DE LO SOLICITADO:")
print("Numero con un decimal: ", format(numero,".1f"))
print("Numero con dos decimales:" , format(numero,".2f"))
print("Numero con tres decimales:" , format(numero,".3f"))
print("Numero con cuatro decimales:", format(numero, ".4f"))
